<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
    <div class="homepage">
    

        <div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
            <?php echo $__env->make('layout.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


        <div class="main-contents">
            <?php echo $__env->yieldContent('contents'); ?>
        </div>

        <div class="container-fluid bg-dark footer pt-5 wow fadeIn" data-wow-delay="0.1s">
        <?php echo $__env->make('layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div> 

       


    </div>
    
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Web 2\web2finalproject\resources\views/layout/master.blade.php ENDPATH**/ ?>