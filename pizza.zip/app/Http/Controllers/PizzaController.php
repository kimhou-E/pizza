<?php

namespace App\Http\Controllers;

use App\Models\Pizza;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; // include DB Class

class PizzaController extends Controller
{


    function showpizza(){
        $pizza_db = DB::table('tbl_pizza')
            ->orderBy('pizza_name', 'asc')
            ->limit(10)
            ->get();


        return view("product", [ "html_pizza" => $pizza_db ] );
    }


    function productdetail(Request $request){

        $m_id = $request -> id;
        $pizza_db = DB::select("select * from tbl_pizza where pizza_id = $m_id  " );
        
        return view("productdetail", [ "tpl_pizza" => $pizza_db  ] );

    }

}
