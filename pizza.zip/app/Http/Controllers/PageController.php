<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class PageController extends Controller
{
    function product(){

        $pizza_db = DB::table('tbl_pizza')
        ->orderBy('pizza_id', 'asc')
        //->limit(10)
        ->get(); // Query SQL

    return view("product", [ "tpl_pizza" => $pizza_db ] );

    }
    function about(){

        return view('about');

    }
    function contact(){

        return view('contact');
    }
    function home(){

        return view('home');

    }
    // function product(){

    //     return view('product');

    // }
    function feature(){

        return view('feature');

    }
    function testimonial(){

        return view('testimonial');

    }

    

   

}
