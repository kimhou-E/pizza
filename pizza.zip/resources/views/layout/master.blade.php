<!DOCTYPE html>
<html lang="en">
<head>
@include('layout.header')
</head>
<body>
    <div class="homepage">
    

        <div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
            @include('layout.nav')
        </div>


        <div class="main-contents">
            @yield('contents')
        </div>

        <div class="container-fluid bg-dark footer pt-5 wow fadeIn" data-wow-delay="0.1s">
        @include('layout.footer')

        </div> 

       


    </div>
    
</body>
</html>
